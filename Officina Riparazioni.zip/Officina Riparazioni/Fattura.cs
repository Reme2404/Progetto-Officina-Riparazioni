﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Officina_Riparazioni
{
    public class Fattura
    {
        public string Marca { get; set; }
        public string Modello { get; set; }
        public int ContoCliente { get; set; }

    }
}
