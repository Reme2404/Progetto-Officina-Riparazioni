﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Officina_Riparazioni
{
    class MeccanicoDormiente : IMeccanico
    {
        //Attributo boolean Stato che se == true farà riposare il meccanico, altrimenti lo farà lavorare
        public bool Stato { get; set; }

        //Metodo RiparaAuto che fa riposare il Meccanico
        public void RiparaAuto(Automobile auto)
        {
            //Se ha lo stato giusto per riposare riposa
            if (this.Stato)
            {
                Console.WriteLine("\n\nIl meccanico è stanco, va a dormi.....ZZZZ...\n.zzZZzz..\n..zZZZz..\n..zZZzz..\n..ZZzZZ..\n..zZZzZZ..\n..\nIl meccanico ora è riposato e torna al lavoro ");
            }
            else
            {
                this.Stato = false;
            }
        }

       
    }
}