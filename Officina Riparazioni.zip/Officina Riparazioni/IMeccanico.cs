﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Officina_Riparazioni
{
    
    interface IMeccanico
    {
        //Attributo stato per la realizzazione dello state pattern
        bool Stato { get; set; }
        //Metodo RiparaAuto che a seconda di chi lo invocherà avrà un comportamento diverso
        void RiparaAuto(Automobile auto);

    }
}
