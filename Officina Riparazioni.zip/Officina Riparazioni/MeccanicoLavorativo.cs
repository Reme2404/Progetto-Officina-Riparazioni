﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Officina_Riparazioni
{
    //Classe che simula il comportamente del Meccanico mentre lavora
    class MeccanicoLavorativo : IMeccanico
    {
        //Attributo boolean Stato che se == false farà lavorare il meccanico, altrimenti lo farà riposare
        public bool Stato { get; set; }
        protected const int sogliaSufficienza = 6;
        const int costoMotoreNuovo = 2000;
        const int costoGommeNuove = 400;
        const int costoSospensioniNuove = 700;
        const int costoFariNuovi = 1200;
        const int costoFreniNuovi = 500;
        const int costoBatteriaNuova = 200;


        //Metodo RiparaAuto che fa lavorare il Meccanico, verrà richiamato per ogni automobile nella lista
        public void RiparaAuto(Automobile auto)
        {
            //Se ha lo stato giusto per lavorare allora lavora
            if (this.Stato == false)
            {
                Console.WriteLine("Eseguo i lavori sull'auto: " + auto.Marca + " " + auto.Modello);
                
                //Ogni componente della macchina viene valutato e se risulta in codizioni non accettabili(cioè il metodo ValutaPezzo returna false)
                //viene invocato il metodo RiparaPezzo per aggiustarlo, altrimenti procedo alla valutazione del pezzo seguente

                if (ValutaPezzo(auto.StatoMotore, "motore") == false)
                {
                    RiparaPezzo(auto, auto.StatoMotore, costoMotoreNuovo, "motore", Officina.Istanza());
                }
                if (ValutaPezzo(auto.StatoGomme, "gomme") == false)
                {
                    RiparaPezzo(auto, auto.StatoGomme, costoGommeNuove, "gomme", Officina.Istanza());
                }
                if (ValutaPezzo(auto.StatoSospensioni, "sospensioni") == false)
                {
                    RiparaPezzo(auto, auto.StatoSospensioni, costoSospensioniNuove, "sospensioni", Officina.Istanza());
                }
                if (ValutaPezzo(auto.StatoFari, "fari") == false)
                {
                    RiparaPezzo(auto, auto.StatoFari, costoFariNuovi, "fari", Officina.Istanza());
                }
                if (ValutaPezzo(auto.StatoFreni, "freni") == false)
                {
                    RiparaPezzo(auto, auto.StatoFreni, costoFreniNuovi, "freni", Officina.Istanza());
                }
                if (ValutaPezzo(auto.StatoBatteria, "batteria") == false)
                {
                    RiparaPezzo(auto, auto.StatoBatteria, costoBatteriaNuova, "batteria", Officina.Istanza());
                }
                Console.WriteLine("\n\nHo finito di eseguire i lavori sull'auto: " + auto.Marca + " " + auto.Modello + "\n" + "Il costo totale per il cliente è di: " + auto.ContoCliente + " euro.\n\n");
            }
            else
            {
                this.Stato = true;
            }
        }

        //Metodo richiamato su ogni pezzo, se le sue condizioni sono sotto la soglia della sufficienza allora returna false(pezzo da riparare),
        //altrimenti returna true(pezzo in ottime condizioni)
        public static bool ValutaPezzo(int condizioniPezzo, string nomePezzo)
        {
            if (condizioniPezzo < sogliaSufficienza)
            {
                Console.WriteLine("Il pezzo " + nomePezzo + " è rovinato, bisognerà ripararlo o eventualmente sostituirlo. ");
                return false;
            }
            Console.WriteLine("Il pezzo " + nomePezzo + " è in ottime condizioni, nessun lavoro necessario.");
            return true;
        }

        //Metodo richiamato su tutti i pezzi di un'automobile in condizioni non sufficienti
        public static void RiparaPezzo(Automobile auto, int condizioniPezzo, int costoRiparazione, string nomePezzo, Officina officina)
        {
            //Modificatore della fortuna, può avere un valore che va da [+3 a -3]
            int fortuna = ModificatoreFortuna();
            //Se le condizoni del pezzo + la fortuna non superano ancora la sogliaSufficienza allora non è possibile riparare il pezzo ma andrà sostituito
            if (condizioniPezzo + fortuna < sogliaSufficienza)
            {
                //Se non posso riparare il pezzo allora lo andrò a sostituire, andando a pagare il prezzo pieno
                Console.WriteLine("Purtroppo la riparazione del pezzo " + nomePezzo + " non è possibile, bisognerà sostituirlo ");
                auto.ContoCliente += costoRiparazione;
                //Ogni volta che sostituisco un pezzo lo prendo da un fornitore dal quale lo pagho il 20% in meno
                officina.AggiornaSpeseFornitore(costoRiparazione - ((costoRiparazione / 100) * 20));
                //Aggiorno le entrate dell'officina
                officina.AggiornaEntrate(costoRiparazione);
                Console.WriteLine("La sostituzione del pezzo costa " + costoRiparazione + "\n" + "Il conto complessivo sale a " + auto.ContoCliente);
                Meccanico.Log(auto, nomePezzo, "sostituito");

            }
            else
            {
                //Se sono qui vuol dire che grazie alla fortuna sono riuscito a riparare il pezzo ed il cliente pagherà la metà
                Console.WriteLine("Sono riuscito a riparare il pezzo " + nomePezzo + ", risparmierai un bel mucchio di soldi");
                //Aggiorno il conto del cliente
                auto.ContoCliente += (costoRiparazione / 2);
                //Aggiorno le entrate dell'officina
                officina.AggiornaEntrate(costoRiparazione / 2);
                Console.WriteLine("La riparazione del pezzo costa " + costoRiparazione / 2 + "\n" + "Il conto complessivo sale a " + auto.ContoCliente);
                Meccanico.Log(auto, nomePezzo, "riparato");
            }

        }
        //Metodo che restituisce una valore randomico compreso tra [-3 e 3]
        public static int ModificatoreFortuna()
        {
            var rand = new Random();
            int fortuna = rand.Next(-3, 4);
            if (fortuna < 0)
            {
                Console.WriteLine("Sei stato sfortunato in questa riparazione !");
            }
            else
            {
                Console.WriteLine("Sei stato fortunato in questa riparazione! Speriamo basti..");
            }

            return fortuna;
        }
    }
}
