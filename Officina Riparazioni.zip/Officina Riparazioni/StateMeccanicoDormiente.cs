﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Officina_Riparazioni
{
    class StateMeccanicoDormiente : IStateMeccanico
    {

        public string GetStateName() {
            return "Sto dormendo\n";
        }
    
        //Metodo RiparaAuto che fa riposare il Meccanico
        public IStateMeccanico RiparaAuto(Automobile auto)
        {  
            Console.WriteLine("\n\nIl meccanico è stanco, va a dormi.....ZZZZ...\n.zzZZzz..\n..zZZZz..\n..zZZzz..\n..ZZzZZ..\n..zZZzZZ..\n..\nIl meccanico ora è riposato e torna al lavoro ");
            return new StateMeccanicoSveglio();
        }

    }
}