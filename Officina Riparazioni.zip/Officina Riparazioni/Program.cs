﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Officina_Riparazioni
{
    class Program
    {
        static void Main(string[] args)
        {
            //Cancello l'eventuale vecchio file contenente i log
            File.Delete("Log.txt");
            //Instanzo un oggetto officina con il pattern SINGLETON
            Officina.Istanza();
            //Istanzio un meccanico
            Meccanico meccanico = new Meccanico();
            //Metodo richiamato nel main per iniziare la giornata lavorativa, inizia caricando tutte le automobili dal file di testo
            //in input per poi metterle in una lista, fatto ciò il meccanico procederà a valutare ogni pezzo di ogni automobile
            int j = 0;
            meccanico.CaricaDaFile(meccanico.automobili);

            for (int i = 0; i < meccanico.automobili.Count; i++) {
                               
                meccanico.RiparaAuto(meccanico.automobili[i]);
                j++;
                if (j == 4)
                {
                    i--;
                    j = 0;
                }
                
            }
            meccanico.CalcolaProfitto();
            meccanico.Fattura(meccanico.automobili);
        }
    }
}
