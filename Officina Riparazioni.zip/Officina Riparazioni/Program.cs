﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Officina_Riparazioni
{
    class Program
    {
        static void Main(string[] args)
        {
            //Cancello l'eventuale vecchio file contenente i log
            File.Delete("Log.txt");
            //Instanzo un oggetto officina con il pattern SINGLETON
            Officina.Instanza();
            //Istanzio un meccanico
            Meccanico meccanico = new Meccanico();
            //Gli faccio iniziare la sua giornata di lavoro
            meccanico.IniziaGiornata();
            
        }
    }
}
