﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Officina_Riparazioni
{
    class Meccanico
    {

        //Attributo che dice quanto è stanco il meccanico, verrà incrementato di uno ogni volta che finirà di lavorare su una macchina
        protected int stanchezza;
        //Costante che dice dopo quante auto il meccanico si riposerà
        protected const int sogliaStanchezza = 3;

     
        //Metodo richiamato nel main per iniziare la giornata lavorativa, inizia caricando tutte le automobili dal file di testo
        //in input per poi metterle in una lista, fatto ciò il meccanico procederà a valutare ogni pezzo di ogni automobile
        public void IniziaGiornata() {
            IMeccanico meccanicoLavoratore = new MeccanicoLavorativo();
            IMeccanico meccanicoDormiente = new MeccanicoDormiente();
            //Ad inizio giornata la stanchezza del meccanico sarà pari a 0
            stanchezza = 0;
            //Variabile necessaria per l'acquisizione degli input da file, indica il percorso del file di input
            //Incollare il percorso del file Input.txt tra le "", esempio: "D:\Progetto PMO\Officina Riparazioni\"
            string filePath;
            Console.WriteLine("Inserire il percorso del file di input compreso il backslash finale: ");
            filePath = Console.ReadLine();
            try
            {
                //Leggo il file
                var lines = File.ReadAllLines(filePath + "Input.txt");
                //Inizializzo una lista di tipo Automobile
                List<Automobile> automobili = new List<Automobile>();
                //Popolo la lista dal file Input.txt
                Console.WriteLine("LISTA DELLE MACCHINE DA FARE OGGI: \n");
                foreach (var item in lines)
                {
                    //Ogni riga equivale ad una macchina con la condizione dei suoi relativi pezzi, separati da ;
                    var elements = item.Split(";");
                    Automobile auto = new Automobile()
                    {
                        Marca = elements[0],
                        Modello = elements[1],
                        StatoMotore = int.Parse(elements[2]),
                        StatoGomme = int.Parse(elements[3]),
                        StatoSospensioni = int.Parse(elements[4]),
                        StatoFari = int.Parse(elements[5]),
                        StatoFreni = int.Parse(elements[6]),
                        StatoBatteria = int.Parse(elements[7]),
                        ContoCliente = int.Parse(elements[8])

                    };

                    //Aggiungo l'autombile alla lista
                    automobili.Add(auto);
                    Console.WriteLine(auto.Marca + " " +auto.Modello);
                }
                Console.WriteLine();
                //Controllo ogni macchina della lista
                for (int i = 0; i < automobili.Count; i++)
                {
                    meccanicoLavoratore.Stato = false;
                    meccanicoLavoratore.RiparaAuto(automobili[i]);
                    //Dopo aver lavorato ad una macchina aumenta la sua stanchezza
                    stanchezza++;
                    //Se la stanchezza raggiugne la soglia allora cambio il suo flag di stato a true, quindi prima di fare la prossima macchina riposerà
                    if (stanchezza >= sogliaStanchezza) {
                        meccanicoLavoratore.Stato = true;
                        meccanicoDormiente.Stato = true;
                        meccanicoDormiente.RiparaAuto(automobili[i]);
                        meccanicoDormiente.Stato = false;
                        stanchezza = 0;
                    }
                }

                Console.WriteLine("\nGIORNATA DI LAVORO FINITA\n");
                //A fine giornata calcolo il profitto
                Console.WriteLine("\nSPESE GIORNATA: " + Officina.Instanza().GetSpeseFornitore() + "\nENTRATE GIORNATA: " + Officina.Instanza().GetEntrateGiornata());
                Console.WriteLine("\nPROFITTO TOTALE DELLA GIORNATA: " + Officina.Instanza().CalcolaProfitto());
            }
            catch (FileNotFoundException) 
            {   
                Console.WriteLine("File di input non trovato, impossibile avviare programma");
            }
        }

        //Metodo per scrivere in un file tutte le operazioni eseguite sulle macchine
        public static void Log(Automobile auto, string nomePezzo, string lavoroEseguito)
        {
            using (TextWriter tsw = new StreamWriter("Log.txt", true))
            {
                tsw.WriteLine($"#### {auto.Marca} {auto.Modello} {" Lavoro eseguito: "} {lavoroEseguito} {nomePezzo}");
            }
        }
    }
}
