﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Officina_Riparazioni
{
    class Officina
    {
        //Attributo instanza necessario per il pattern SINGLETON
        private static Officina instanza = null;
        //Entrate della giornata
        private int entrateGiornata;
        //Spese della giornata
        private int speseFornitore;


        protected Officina() {
            this.entrateGiornata = 0;
            this.speseFornitore = 0;
        }

        //Metodo necessario per il pattern SINGLETON, verrà richiamato ogni volta che userò l'oggetto Officina, 
        //per controllare se sia già instanziato o se è necessario instanziarlo, tutto ciò per far si che ci sia solo una sua istanza
        public static Officina Instanza(){
            if (instanza == null)
            {
                instanza = new Officina();
            }
            return instanza;
        }

        //Metodo per aggiornare le spese giornaliere
        public void AggiornaSpeseFornitore(int aggiunta)
        {
            this.speseFornitore += aggiunta;
        }

        //Metodo per aggiornare le entrate della giornata
        public void AggiornaEntrate(int pagamento) 
        {
            this.entrateGiornata += pagamento;
        }

        //Metodo per calcolare il profitto a fine giornata
        public int CalcolaProfitto()
        {
            return (this.entrateGiornata - this.speseFornitore);
        }

        public int GetEntrateGiornata() {
            return this.entrateGiornata;
        }

        public int GetSpeseFornitore() {
            return this.speseFornitore;
        }
    }
}
